from project.task import Task


class Section:

    def __init__(self, name: str) -> None:
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if not new_task in self.tasks:
            self.tasks.append(new_task)
            return f"Task {Task.details(new_task)} is added to the section"
        return f"Task is already in the section {self.name}"

    def complete_task(self, task_name: str):
        task = [taska for taska in self.tasks if taska.name == task_name]
        if task:
            checked = task[0]
            checked.completed = True
            return f"Completed task {task_name}"
        return f"Could not find task with the name {task_name}"

    def clean_section(self):
        trued = [tru for tru in self.tasks if tru.completed]
        cleared = len(trued)
        for el in trued:
            self.tasks.remove(el)
            return f"Cleared {cleared} tasks."
        return f"Cleared 0 tasks."

    def view_section(self):
        result = ""
        result += f"Section {self.name}:\n"
        for tsk in self.tasks:
            result += f"{tsk.details()}\n"
        return result
