from project.room import Room


class Hotel:

    def __init__(self, name: str) -> None:
        self.name = name
        self.rooms = []
        self.guests = 0

    @classmethod
    def from_stars(cls, stars_count: int):
        hotel_name = f"{stars_count} stars Hotel"
        return cls(hotel_name)

    def add_room(self, room: Room):
        self.rooms.append(room)

    def take_room(self, room_number: int, people: int):
        room = [r for r in self.rooms if r.number == room_number][0]
        result = room.take_room(people)
        if result:
            self.guests += people
        # for room in self.rooms:
        #     if room == room_number and room.capacity >= people:
        #         room.take_room(people)

    def free_room(self, room_number):
        room = [r for r in self.rooms if r.number == room_number][0]
        self.guests -= room.guests
        room.free_room()

    def status(self):
        free_rooms_num = [r.number for r in self.rooms if not r.is_taken]
        taken_rooms = [r.number for r in self.rooms if r.is_taken]
        result = f"Hotel {self.name} has {self.guests} total guests"'\n' \
                 f"Free rooms: {', '.join(map(str, free_rooms_num))}"'\n' \
                 f"Taken rooms: {', '.join(map(str, taken_rooms))}"

        return result
